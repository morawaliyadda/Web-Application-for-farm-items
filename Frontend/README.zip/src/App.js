import React from "react";
import './App.css';
import {BrowserRouter, Route,Routes} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';



import Header from './components/Header/Header';
import Footer from './components/Footer/Footer';
import HomeScreen from './screens/Homescreen';
import ProductScreen from './screens/ProductScreen';
import AboutScreen from './screens/AboutScreen';
import ContactUsScreen from './screens/ContactUsScreen';
import SignIn from './screens/SignIn';
import  SignUp  from './screens/SignUp';
import Cart from './components/Cart/Cart';
import PaymentForm from './components/Payment/Payment';
import Allproducts from './screens/products';
import AdminDashboard from './screens/Adminpage';
import OrderSuccess from './screens/thankyou';
import SearchBar from './components/SearchBar/Seachbar';




function App() {

  return (
    <BrowserRouter>
    <div className="App">
      <header > 
       <Header/>
      </header>
      <main>
        <Routes>
          <Route path='/' element={<HomeScreen/>}/>
          <Route path='/product/:slug' element={<ProductScreen/>}/>
          <Route path='/about' element={<AboutScreen/>}/>
          <Route path='/contact' element={<ContactUsScreen/>}/>
          <Route path='/SignIn' element={<SignIn/>}/>
          <Route path='/SignUp' element={<SignUp/>}/>
          <Route path='/product' element={<Allproducts/>}/>
          <Route path='/cart' element={<Cart/>}/>
          <Route path='/pay' element={<PaymentForm/>}/>
          <Route path='/admin' element={<AdminDashboard/>}/>
          <Route path='/thankyou' element={<OrderSuccess/>}/>
          <Route path="/srceens/ProductScreen" element={<SearchBar/>} />
          
        </Routes>
      </main>
      <Footer/>
    </div>
    </BrowserRouter>
    
  );
}

export default App;
