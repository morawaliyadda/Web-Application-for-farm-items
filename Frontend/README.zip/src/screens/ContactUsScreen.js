
import React, { useState } from 'react';
import '../App.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEnvelope, faPhone, faMapMarkerAlt } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios'; 
import {useNavigate} from 'react-router-dom';

function ContactUsScreen() {

  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    username: '',
    email: '',
    message: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
  

    const apiUrl = 'http://localhost:3001/message/'; 
  
 
    const messageData = {
      username: formData.username,
      email: formData.email,
      message: formData.message,
      
    };
  

    axios.post(apiUrl, messageData)
      .then((result) => {
        console.log(result.data);
          navigate("../");
        
      })
      .catch((err) => console.error("Error during login:", err));
  };
  

  return (
    <section className="contact" id="contact">
      <h1 className="contact-heading">
        <span>Contact</span> Us
      </h1>
      <div className="contact-row">
        <div className="content">
          <h3 className="contact-title">Contact info</h3>
          <div className="contact-info">
            <h3>
              <FontAwesomeIcon icon={faEnvelope} /> FarmFreash@gmail.com
            </h3>
            <h3>
              <FontAwesomeIcon icon={faPhone} /> +94-11-030-0989
            </h3>
            <h3>
              <FontAwesomeIcon icon={faPhone} /> +94-81-101-6908
            </h3>
            <h3>
              <FontAwesomeIcon icon={faMapMarkerAlt} /> 110, Hapugala, Galle.
            </h3>
          </div>
        </div>
        <div className="contact-form">
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              name="username"
              placeholder="Name"
              className="box"
              value={formData.username}
              onChange={handleChange}
            />
            <input
              type="email"
              name="email"
              placeholder="Email"
              className="box"
              value={formData.email}
              onChange={handleChange}
            />
            <textarea
              name="message"
              placeholder="Message"
              cols="30"
              rows="10"
              className="box message"
              value={formData.message}
              onChange={handleChange}
            ></textarea>
            <button type="submit" className="contact-submitbtn">
              Send <i className="fas fa-paper-plane"></i>
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}

export default ContactUsScreen;
