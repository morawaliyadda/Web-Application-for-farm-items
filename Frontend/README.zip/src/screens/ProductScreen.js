import React, {useState} from "react";
import { useParams ,Link } from "react-router-dom";
import data from '../components/Product/datalist';
import 'bootstrap/dist/css/bootstrap.css';
import '../App.css'

function ProductScreen({cart,setCart}){
    const params =useParams();
    const {slug} = params;
    
    const product = data.vegeproducts.concat(data.fruitsproducts, data.farmproducts).find(product => product.slug === slug);
    
    const [quantity, setQuantity] = useState(1);

    
   
    
    const increaseQuantity = () => {
        setQuantity(quantity + 1);
      };
  
      const decreaseQuantity = () => {
        if (quantity > 1) {
          setQuantity(quantity - 1);
        }
    };

    const addToCart = () => {
        const cartItem = { ...product, quantity }; 
        setCart([...cart, cartItem]); 
    };

    if (!product) {
        return <div>Product not found</div>;
    }
    
    return (
    <div className="row">
        <div className="col-md-4">
            <img  src={product.image} alt={product.name} />
        </div>
        <div className="col-md-4">
            <h1 >{product.name}</h1>
            <h4>Price      : Rs.{product.price}</h4>
            <p className ="text-left">{product.description}</p>
            <h6>In Stock   :{product.Instock }</h6>
            <div className="cartbtn">
                <a href='/'>
                <Link to="/cart">
                    <button onClick={addToCart}>Add to cart</button>
                </Link>
               
                </a>
                    
            </div>
            
            
        </div>
        <div className="col-md-4">
        <h5>Quantity</h5>
        <div className="quantity-controls">
            <button onClick={decreaseQuantity}>-</button>
            <span>{quantity}</span>
            <button onClick={increaseQuantity}>+</button>
        </div>
        </div>
        
      
    </div>
    );
}
export default ProductScreen;