import React, { useState, useEffect } from 'react';
import axios from 'axios';
import MessageList from './MessageSCreen';

const Adminpage = () => {
  const [payments, setPayments] = useState([]);

  useEffect(() => {
    const fetchPayments = async () => {
      try {
        const response = await axios.get('http://localhost:3001/payment/payments');
        setPayments(response.data);
      } catch (error) {
        console.error('Error fetching payments:', error);
      }
    };

    fetchPayments();
  }, []);
  

  const handleDeletePayment = async (paymentId) => {
    try {
      await axios.delete(`http://localhost:3001/payment/payments/${paymentId}`);
      setPayments(payments.filter((payment) => payment._id !== paymentId));
    } catch (error) {
      console.error('Error deleting payment:', error);
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4">All Payments</h2>
      <table className="table table-striped">
        <thead className="table-dark">
          <tr>
            <th>Customer Name</th>
            <th>Address</th>
            <th>Contact Number</th>
            <th>Cardholder Name</th>
            <th>Bank Name</th>
            <th>Account Number</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {payments.map((payment) => (
            <tr key={payment._id}>
              <td>{payment.customername}</td>
              <td>{payment.address}</td>
              <td>{payment.contactno}</td>
              <td>{payment.cardholdername}</td>
              <td>{payment.bankname}</td>
              <td>{payment.accountno}</td>
              <td>
                <button className="btn btn-danger" onClick={() => handleDeletePayment(payment._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <MessageList />
    </div>
  );
};

export default Adminpage;
