import React from "react";
import Category from "../components/Categories/Categories";
import VegetableProducts from "../components/Product/VegetaProducts";
import FruitsProducts from "../components/Product/FruitProduct";
import FarmProducts from "../components/Product/FarmProduct";
import SearchBar from "../components/SearchBar/Seachbar";
 



function HomeScreen(){
    return(
     <div>
        <SearchBar/>
        <Category/>
        <VegetableProducts />
        <FruitsProducts/>
        <FarmProducts/>
    </div>
    );
}
export default HomeScreen;