import React from 'react';
import data from './datalist.jsx';
import './Product.css';
import { Link } from 'react-router-dom';

const VegetableProducts = () => {
  return (
    <div className="container">
      <h2 className='name'>Vegetables</h2>
      <div className="row product-list">
        {data.vegeproducts.map((product) => (
          <div key={product.slug} className="col-md-3 mb-3">
            <div className="card product">
              <Link to={`/product/${product.slug}`}>
                <img src={product.image} className="card-img-top" alt={product.name} />
              </Link>
              <div className='card-body text'>
                <Link to={`/product/${product.slug}`}>
                  <h3 className="card-title">{product.name}</h3>
                </Link>
                <h5>{product.Quantity}</h5>
                <h4><strong>Rs.{product.price}</strong></h4>
                <div className='cartbtn'>
                  <button className="btn btn-success btn-block">Add to Cart</button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default VegetableProducts;
