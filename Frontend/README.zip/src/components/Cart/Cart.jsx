import React from "react";
import "./Cart.css"; // Import your CSS file

function Cart({ items, onRemove, onUpdate }) {
  return (
    <div className="cart-container">
      <h2>Shopping Cart</h2>
      <div className="cart-items">
        {items.map((item) => (
          <div className="cart-item" key={item.id}>
            <img src={item.image} alt={item.name} />
            <div className="item-details">
              <h3>{item.name}</h3>
              <p>Price: Rs. {item.price}</p>
              <p>Quantity: {item.quantity}</p>
              <p>Total: Rs. {item.price * item.quantity}</p>
            </div>
            <div className="item-actions">
              <button onClick={() => onUpdate(item.id, item.quantity - 1)}>-</button>
              <button onClick={() => onUpdate(item.id, item.quantity + 1)}>+</button>
              <button onClick={() => onRemove(item.id)}>Remove</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Cart;
