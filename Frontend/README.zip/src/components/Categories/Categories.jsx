import React from 'react';
import './Categories.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from 'react-router-dom';

const Category = ({ onCategorySelect }) => {
  return (
    <div className="category-container">
      <div className="category-topic">
        <h2>Category</h2>
      </div>
      <div className="category-buttons">
        <Link to="/datalist/data/vegeproducts"> 
          <button className="btn btn-primary">
            Vegetables
          </button>
        </Link>
        <Link to="/fruits"> 
          <button className="btn btn-primary">
            Fruits
          </button>
        </Link>
        <Link to="/FarmProduct"> 
          <button className="btn btn-primary">
            Farm Product
          </button>
        </Link>
      </div>
    </div>
  );
};

export default Category;
